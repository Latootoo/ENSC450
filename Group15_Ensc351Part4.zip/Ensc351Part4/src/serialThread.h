/* ENSC-351, Simon Fraser University -- 2013, By
 *  - Craig Scratchley
 *  - Zhenwang Yao.
 */
 
#ifndef SPSERVER_H_
#define SPSERVER_H_

void* SerialThrd(void *param);

#endif /*SPSERVER_H_*/
